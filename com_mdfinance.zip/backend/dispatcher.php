<?php
/**
* @package MDFinance
* @copyright Copyright (c)2013 Martijn Hiddink / mardinkwebdesign.com
* @license GNU General Public License version 3 or later
*/

defined('_JEXEC') or die();

class MdfinanceDispatcher extends FOFDispatcher
{
    public $defaultView = 'cpanels';
}