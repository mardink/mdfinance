DROP TABLE IF EXISTS `#__mdfinance_invoices`;
